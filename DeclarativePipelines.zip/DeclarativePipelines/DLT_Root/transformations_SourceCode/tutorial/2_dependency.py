# import dlt
# import pyspark.sql.functions as F
# from pyspark.sql.functions import *
# '''creating the end to end data pipeline'''
# #staging area
# @dlt.table(
#     name = "staging_orders"
# )
# def staging_orders():
#     df = spark.readStream.table("dltsiva.source.orders")
#     return df

# # transformed area
# @dlt.view(
#     name = "transformed_orders"
# )
# def transformed_orders():
#     df = spark.readStream.table("staging_orders")
#     df = df.withColumn("order_id", lower(col('order_id')))
#     return df 

# #creating the aggregated area
# @dlt.table(
#     name = "aggregated_orders"
# )
# def aggregated_orders():
#     df = spark.readStream.table("transformed_orders")
#     df = df.groupBy("order_status").count()
#     return df
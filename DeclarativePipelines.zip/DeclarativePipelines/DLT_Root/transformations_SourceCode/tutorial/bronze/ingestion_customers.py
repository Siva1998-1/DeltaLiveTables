import dlt

#Expectations of customers
customers_rules = {
    "rules_1" : "customer_id IS NOT NULL",
    "rules_2" : "customer_name IS NOT NULL"
}
# creating the customers_stg straming table 
@dlt.table(
  name="customers_stg"
)
@dlt.expect_all(customers_rules)
def customers_stg():
  df = spark.readStream.table("dltsiva.source.customers")
  return df
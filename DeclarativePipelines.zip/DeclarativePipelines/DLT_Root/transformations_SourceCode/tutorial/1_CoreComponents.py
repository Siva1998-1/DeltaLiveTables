# import dlt
# # create streaming table
# @dlt.table(
#   comment="first_stream_table"
# )

# def first_stream_table():
#     df=spark.readStream.table("dltsiva.source.orders")
#     return df

# #create materialized view

# @dlt.table(
#   name="first_mat_view"
# )
# def first_mat_view():
#     df=spark.read.table("dltsiva.source.orders")
#     return df

# #create the views
# #create the batch view 
# @dlt.view(
#   name="first_batch_view"
# )
# def first_batch_view():
#     df=spark.read.table("dltsiva.source.orders")
#     return df
# #create the streaming view 
# @dlt.view(
#   name="first_stream_view"
# )
# def first_stream_view():
#     df=spark.readStream.table("dltsiva.source.orders")
#     return df


